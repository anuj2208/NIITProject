package com.anuj.onlineShop.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.anuj.onlineShop.model.Supplier;

@Repository
public class SupplierDAOImpl implements SupplierDAO {
	
	@Autowired
	private SessionFactory sessionFactory;


	@Override
	public Supplier getSupplierById(int supplierId) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			Supplier supplier = (Supplier) session.get(Supplier.class, supplierId);
			session.getTransaction().commit();
			return supplier;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteSupplier(int supplierId) {
		
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Supplier supplier = (Supplier) session.get(Supplier.class, supplierId);
			session.delete(supplier);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@Override
	public void addSupplier(Supplier supplier) {
		
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(supplier);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@Override
	public void updateSupplier(Supplier supplier) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			session.saveOrUpdate(supplier);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		
	}

	@Override
	public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<Supplier>();
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			CriteriaQuery<Supplier> criteriaQuery = criteriaBuilder.createQuery(Supplier.class);
			Root<Supplier> root = criteriaQuery.from(Supplier.class);
			criteriaQuery.select(root);
			suppliers = session.createQuery(criteriaQuery).getResultList();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return suppliers;
	}

}
