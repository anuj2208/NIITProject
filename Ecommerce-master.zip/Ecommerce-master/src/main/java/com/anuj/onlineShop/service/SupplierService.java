package com.anuj.onlineShop.service;

import java.util.List;

import com.anuj.onlineShop.model.Supplier;

public interface SupplierService {
	
	List<Supplier> getAllSuppliers();
    
	Supplier getSupplierById(int supplierId);

    void deleteSupplier(int supplierId);
    
    void addSupplier(Supplier supplierId);
    
    void updateSupplier(Supplier supplierId);
}
