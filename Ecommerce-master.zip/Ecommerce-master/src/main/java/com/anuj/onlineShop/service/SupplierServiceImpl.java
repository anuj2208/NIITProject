package com.anuj.onlineShop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anuj.onlineShop.dao.SupplierDAO;
import com.anuj.onlineShop.model.Supplier;

@Service
public class SupplierServiceImpl implements SupplierService {
	
	@Autowired
    private SupplierDAO supplierDao;
	
	@Override
	public List<Supplier> getAllSuppliers() {
		return supplierDao.getAllSuppliers();
	}

	@Override
	public Supplier getSupplierById(int supplierId) {
		return supplierDao.getSupplierById(supplierId);
	}

	@Override
	public void deleteSupplier(int supplierId) {
		supplierDao.deleteSupplier(supplierId);
		
	}

	@Override
	public void addSupplier(Supplier supplier) {
		supplierDao.addSupplier(supplier);
		
	}

	@Override
	public void updateSupplier(Supplier supplierId) {
		supplierDao.updateSupplier(supplierId);
		
	}

}
