package com.anuj.onlineShop.dao;

import java.util.List;

import com.anuj.onlineShop.model.Category;

public interface CategoryDAO {

	Category getCategoryById(int categoryId);

	void deleteCategory(int categoryId);

	void addCategory(Category categoryId);

	void updateCategory(Category categoryId);

	List<Category> getAllCategories();
}
