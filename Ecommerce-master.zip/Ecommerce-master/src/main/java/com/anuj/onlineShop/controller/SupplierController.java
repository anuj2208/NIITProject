package com.anuj.onlineShop.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.anuj.onlineShop.model.Supplier;
import com.anuj.onlineShop.service.SupplierService;

@Controller
public class SupplierController {

	@Autowired
	private SupplierService supplierService;
	
	@RequestMapping(value = "/getAllSuppliers", method = RequestMethod.GET)
	public ModelAndView getAllSuppliers() {
		List<Supplier> suppliers = supplierService.getAllSuppliers();
		return new ModelAndView("supplierList", "suppliers", suppliers);
	}
	
	
	@RequestMapping(value = "/getSupplierById/{supplierId}", method = RequestMethod.GET)
	public ModelAndView getSupplierById(@PathVariable(value = "supplierId") int supplierId) {
		Supplier supplier = supplierService.getSupplierById(supplierId);
		return new ModelAndView("supplierPage", "supplier", supplier);
	}
	
	@RequestMapping(value = "/admin/supplier/delete/{supplierId}", method = RequestMethod.GET)
	public String deleteSupplier(@PathVariable(value = "supplierId") int supplierId) {		
		supplierService.deleteSupplier(supplierId);
		return "redirect:/getAllSuppliers";
	}
		
		
		@RequestMapping(value = "/admin/supplier/addSupplier", method = RequestMethod.GET)
		public ModelAndView getSupplierForm() {
			return new ModelAndView("addSupplier", "supplierForm", new Supplier());
		}
	
	

		@RequestMapping(value = "/admin/supplier/addSupplier", method = RequestMethod.POST)
		public String addSupplier(@Valid @ModelAttribute(value = "supplierForm") Supplier supplier, BindingResult result) {

			if (result.hasErrors()) {
				return "addSupplier";
			}
			supplierService.addSupplier(supplier);

			return "redirect:/getAllSuppliers";
		}
	
	
		@RequestMapping(value = "/admin/supplier/editSupplier/{supplierId}")
		public ModelAndView getEditForm(@PathVariable(value = "supplierId") int supplierId) {
			Supplier supplier = supplierService.getSupplierById(supplierId);
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("editSupplier");
			modelAndView.addObject("editSupplierObj", supplier);
			modelAndView.addObject("supplierId", supplierId);

			return modelAndView;
		}
	
	
	
		@RequestMapping(value = "/admin/supplier/editSupplier/{supplierId}", method = RequestMethod.POST)
		public String editSupplier(@ModelAttribute(value = "editSupplierObj") Supplier supplier,
				@PathVariable(value = "supplierId") int supplierId) {
			supplier.setId(supplierId);
			supplierService.updateSupplier(supplier);
			return "redirect:/getAllSuppliers";
		}
	

	
}
