package com.anuj.onlineShop.dao;

import java.util.List;

import com.anuj.onlineShop.model.Supplier;

public interface SupplierDAO {

	Supplier getSupplierById(int supplierId);

	void deleteSupplier(int supplierId);

	void addSupplier(Supplier supplierId);

	void updateSupplier(Supplier supplierId);

	List<Supplier> getAllSuppliers();
	
}
