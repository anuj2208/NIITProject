package com.anuj.onlineShop.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.anuj.onlineShop.model.Category;
import com.anuj.onlineShop.service.CategoryService;

@Controller
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@RequestMapping(value = "/getAllCategories", method = RequestMethod.GET)
	public ModelAndView getAllCategories() {
		List<Category> categories = categoryService.getAllCategories();
		return new ModelAndView("categoryList", "categories", categories);
	}
	
	@RequestMapping(value = "/getCategoryById/{categoryId}", method = RequestMethod.GET)
	public ModelAndView getCategoryById(@PathVariable(value = "categoryId") int categoryId) {
		Category category = categoryService.getCategoryById(categoryId);
		return new ModelAndView("categoryPage", "category", category);
	}
	
	@RequestMapping(value = "/admin/category/delete/{categoryId}", method = RequestMethod.GET)
	public String deleteCategory(@PathVariable(value = "categoryId") int categoryId) {		
		categoryService.deleteCategory(categoryId);
		return "redirect:/getAllCategories";
	}
	
	
	@RequestMapping(value = "/admin/category/addCategory", method = RequestMethod.GET)
	public ModelAndView getCategoryForm() {
		return new ModelAndView("addCategory", "categoryForm", new Category());
	}
	
	
	@RequestMapping(value = "/admin/category/addCategory", method = RequestMethod.POST)
	public String addCategory(@Valid @ModelAttribute(value = "categoryForm") Category category, BindingResult result) {

		if (result.hasErrors()) {
			return "addCategory";
		}
		categoryService.addCategory(category);

		return "redirect:/getAllCategories";
	}
	
	@RequestMapping(value = "/admin/category/editCategory/{categoryId}")
	public ModelAndView getEditForm(@PathVariable(value = "categoryId") int categoryId) {
		Category category = categoryService.getCategoryById(categoryId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("editCategory");
		modelAndView.addObject("editCategoryObj", category);
		modelAndView.addObject("categoryId", categoryId);

		return modelAndView;
	}
	
	
	@RequestMapping(value = "/admin/category/editCategory/{categoryId}", method = RequestMethod.POST)
	public String editCategory(@ModelAttribute(value = "editCategoryObj") Category category,
			@PathVariable(value = "categoryId") int categoryId) {
		category.setId(categoryId);
		categoryService.updateCategory(category);
		return "redirect:/getAllCategories";
	}

	@RequestMapping("/getCategoriesList")
	public @ResponseBody List<Category> getCategoriesListJson() {
		return categoryService.getAllCategories();
	}
	
	
	
	
}
