package com.anuj.onlineShop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anuj.onlineShop.dao.CategoryDAO;
import com.anuj.onlineShop.model.Category;

@Service
public class CategoryServiceImpl implements CategoryService {
	@Autowired
    private CategoryDAO categoryDao;

	@Override
	public List<Category> getAllCategories() {
	   	 return categoryDao.getAllCategories();

	}

	@Override
	public Category getCategoryById(int categoryId) {
		 return categoryDao.getCategoryById(categoryId);
	}

	@Override
	public void deleteCategory(int categoryId) {
		categoryDao.deleteCategory(categoryId);
	}

	@Override
	public void addCategory(Category category) {
		categoryDao.addCategory(category);
	}

	@Override
	public void updateCategory(Category category) {
		categoryDao.updateCategory(category);
	}

}
