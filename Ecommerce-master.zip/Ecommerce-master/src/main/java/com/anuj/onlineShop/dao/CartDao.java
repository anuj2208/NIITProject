package com.anuj.onlineShop.dao;

import java.io.IOException;

import com.anuj.onlineShop.model.Cart;

public interface CartDao {
	Cart getCartById(int cartId);

	Cart validate(int cartId) throws IOException;
}
