package com.anuj.onlineShop.dao;

import com.anuj.onlineShop.model.SalesOrder;

public interface SalesOrderDao {
    void addSalesOrder(SalesOrder SalesOrder);
}
