package com.anuj.onlineShop.service;

import java.util.List;

import com.anuj.onlineShop.model.Category;


public interface CategoryService {
	
	List<Category> getAllCategories();
    
	Category getCategoryById(int productId);

    void deleteCategory(int categoryId);
    
    void addCategory(Category category);
    
    void updateCategory(Category category);
}
